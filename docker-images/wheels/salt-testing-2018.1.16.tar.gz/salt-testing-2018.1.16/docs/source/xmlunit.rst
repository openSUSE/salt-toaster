.. automodule:: salttesting.xmlunit
    :members:
