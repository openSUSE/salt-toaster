.. automodule:: salttesting.case
    :members:
