.. automodule:: salttesting.mixins
    :members:
