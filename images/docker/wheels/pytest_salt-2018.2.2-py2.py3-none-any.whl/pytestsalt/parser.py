# -*- coding: utf-8 -*-
'''
    :codeauthor: :email:`Pedro Algarvio (pedro@algarvio.me)`
    :copyright: Copyright 2015 by the SaltStack Team, see AUTHORS for more details.
    :license: Apache 2.0, see LICENSE for more details.


    pytestsalt.parser
    ~~~~~~~~~~~~~~~~~

    pytest salt plugin related parser options
'''

# Import python libs
from __future__ import absolute_import
