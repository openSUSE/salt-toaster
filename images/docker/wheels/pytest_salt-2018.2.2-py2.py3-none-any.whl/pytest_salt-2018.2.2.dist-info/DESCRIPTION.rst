PyTest Salt Plugin
==================

This plugin will allow the Salt Daemons to be used in tests.

This plugin is currently being used in Salt's test suite for the develop branch, however,
this is still considered beta software.
Please do submit bug reports for any issues you find.


