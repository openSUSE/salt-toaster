Authors
=======

Here's a list of everyone who contributed to salt-testing in alphabetical
order.

==========================  =====================  ============================
Name                        Nick                   Email
==========================  =====================  ============================
Erik Johnson                terminalmage           erik@saltstack.com
Henrik Holmboe              holmboe
Mike Place                  cachedout              mp@saltstack.com
Niels Abspoel               aboe76
Pedro Algarvio              s0undt3ch              pedro@algarvio.me
Thomas S. Hatch             thatch45               thatch45@saltstack.com
==========================  =====================  ============================
