# -*- coding: utf-8 -*-
'''
pytestsalt.fixtures
~~~~~~~~~~~~~~~~~~~

pytest salt fixtures
'''
